
DEtime <- function(times,ControlData,PerturbedData,replicate_no, gene_no, times_test=times,gene_ID=NULL) {

## DEtime fits a mixed GP model on two dataset composed of both control data and perturbed data which diverges at a single perturbation point. The two dataset before the presumed perturbation point are fitted with a single GP and after the perturbation point, they are fitted with two independent GPs. The posterior distribution of the tested perturbation points is then obtained from which all thesestatistical info, for example, the MEDIAN, MODE and 5-95 percentile of the distribution can be derived.      
## ARG times: The time points of the measured data. At the moment, it is assumed the control and perturbed data are measured at exactly the same time points.
## ARG times_test: The time points which will be tested for perturbation effects. The original time points will be used if it is not provided.
## ARG replicate_no: The replicate nos of the meaured data. At the moment, same number of replicates are accepted for this model. If this is not provided, the value will be obtained by comparing the size of the measured data and the length of the time points
## ARG ControlData : The control dataset used in the model, which is ordered by the first replicate for all time points then the second replicate for all time points and so on
## ARG PerturbedData : The perturbed dataset used in the model, which is ordered by the first replicate for all time points then the second replicate for all time points and so on
## COPYRIGHT: Jing Yang, 2015
##


#pathnames <- list.files(pattern="[.]R$", path = "~/*.R", full.names = TRUE)
#sapply(pathnames,FUN=source)

if (is.null(times)) {
    stop("Time points for the measurements are not provided, pls provide times.")
}

if (is.null(times_test)) {
    times_test <- times
}

if (is.null(replicate_no)){
    stop("Replicate no for the measurements is not provided, pls provide replicate_no.")
}

if (is.null(gene_no)){
    stop("number of genes studies is not provided, pls provide gene_no.")
}

if (is.null(ControlData)){
    stop("Control data are not provided, pls provide ControlData.")
}
else{
    dim(ControlData) <- c(gene_no, length(times)*replicate_no)
}

if (is.null(PerturbedData)){
    stop("Perturbed data are not provided, pls provide PerturbedData.")
}
else{
    dim(PerturbedData) <- c(gene_no, length(times)*replicate_no)
}

if ((is.null(dim(ControlData)))||(is.null(dim(ControlData)))||(!all.equal((dim(ControlData)),dim(PerturbedData)))){
    stop("Dimension of the input data is not correct, please note ControlData and PerturbedData are both matrix and have to be in the same size.")
}


if (is.null(gene_ID)){
    gene_ID <- as.character(seq(1,gene_no))
}

if (dim(ControlData)[2] != replicate_no*length(times) || (dim(ControlData)[1] != gene_no)){
    browser()
    stop("Dimension of the data doesn't match, pls double check ")
}

if ((max(times_test)>max(times))||(min(times_test)<min(times))){
    stop("input perturbation test points is our of the range of original times, pls change times_test")
}

### interpolation points
Data <- cbind(PerturbedData, ControlData)
times_rep2 <- rep(times, 2*replicate_no)
len_times <- length(times) 
len_test <- length(times_test)

DEtimeOutput <- list()
MAP_DEtime <- matrix(0,nrow=gene_no,ncol=1)
mean_DEtime <- matrix(0,nrow=gene_no,ncol=1)
median_DEtime <- matrix(0,nrow=gene_no,ncol=1)
ptl5_DEtime <- matrix(0,nrow=gene_no,ncol=1)
ptl95_DEtime <- matrix(0,nrow=gene_no,ncol=1)
model_DEtime <- vector("list",gene_no)

posterior <- matrix(0,nrow=gene_no,ncol=len_test)
best_param <- matrix(0,nrow=gene_no,ncol=4)
model_DEtime <- list()
#### model and parameters initialization
for (idx in seq(1,gene_no)){
model <- list() ## Allocate space for model.
### Initialize hyperparameters used in the GP model
param <- rep(0, 5)  ## Hyperparameters
### Likelihood for each tested perturbation point of each gene
likelihood <- rep(0, len_test) ##  the likelihood
#browser()
x <- matrix(times_rep2, ncol=1)
y <- matrix(scale((Data[idx,]),center=TRUE,scale=TRUE), ncol=1)

options=gpOptions(approx="ftc")
options$kern = list(type="cmpnd",comp=list(list(type="DEtime",options=list(inverseWidthBounds=c(1/(2*max(times)),1/(min(times)+0.25*(max(times)-min(times)))),varianceBounds=c(min(min(y),0.5),max(max(y),5)))),list(type="white")))
  if (sum(is.nan(y)) > (length(y)/2)) {
    cat('Majority of points in profile are NaN.\n')
    next
    }

options$isMissingData <- any(is.nan(y))
options$isSpherical <- !any(is.nan(y))
stdy = sd(c(y[!is.nan(y)])) ## Profile variance.

## Optimise GP log likelihoods.
model0 <- gpCreate(dim(x)[2], dim(y)[2], x, y, options)
model0 <- gpOptimise(model0,0)
param0 <- gpExtractParam(model0)  ## get optimized hyperparameters

param <- matrix(rep(param0,times=len_test), nrow = len_test, byrow=TRUE)
  
## estimate the likelihood for each tested time point

for (i in seq_along(times_test)){
    param0[3] <- times_test[i]
    model[[i]] = gpExpandParam(model0,param0)
    likelihood[i] <- exp(gpLogLikelihood(model[[i]]))
}
    

posterior[idx,] <- likelihood/sum(likelihood)
cum_posterior <- cumsum(likelihood/sum(likelihood))
MAP_DEtime[idx] <- times_test[which.max(likelihood)]
median_DEtime[idx] <- times_test[which(cum_posterior>0.50)[1]]
mean_DEtime[idx] <- sum(times_test * posterior[idx,])
ptl5_DEtime[idx] <- times_test[which(cum_posterior>0.05)[1]]
ptl95_DEtime[idx] <- times_test[which(cum_posterior>0.95)[1]]
param0[3] <- MAP_DEtime[idx,] ## use MAP as the best perturbation point
best_param[idx,] <- as.matrix(param0, nrow=1)
model_DEtime[[idx]] <- model0
}

#tstar <- matrix(seq(min(times)-(2*(max(times)-min(times))/10), max(times), length=200), ncol=1)
#  tstar2 <- matrix(rep(tstar,2, bycol=TRUE), ncol=1)

#if (TRUE) {
#    param0[3] <- times_test[which(likelihood==max(likelihood))]
#    model0 <- gpExpandParam(model0,param0)
#    Kx = kernCompute(model0$kern, x, tstar2)
#    Ktrain = kernCompute(model0$kern, x)
#    invKtrain = .jitCholInv(Ktrain, silent=TRUE)$invM
#    yPred = t(Kx) %*% invKtrain %*% y
#    yVar =diag(abs(kernCompute(model0$kern, tstar2) - t(Kx) %*% invKtrain %*% Kx))

#    gpPlot_DEtime(model0, tstar2, yPred, yVar, cbind(times_test,posterior), title =paste('GP regression plot of ',gene_ID,' with perturbation time at ',format(param0[3],digits=4),sep=""))
#    gpPlot_DEtime(model0, tstar2, yPred, yVar, cbind(times_test,posterior), title =paste('GPR result for ',gene_ID, ' by DEtime package', sep=""))

#}


DEtimeOutput$posterior <- posterior
DEtimeOutput$best_param <- best_param
DEtimeOutput$result <- data.frame(gene_ID = gene_ID, MAP= format(MAP_DEtime, digits=4, nsmall=2), mean = format(mean_DEtime, digits=4, nsmall=2), median = format(median_DEtime, digits=4, nsmall=2), ptl5 = format(ptl5_DEtime, digits=4, nsmall=2), ptl95 = format(ptl95_DEtime, digits=4, nsmall=2))

DEtimeOutput$originaltimes <- x
DEtimeOutput$originaldata <- Data
DEtimeOutput$times_test <- times_test
DEtimeOutput$model <- model_DEtime
DEtimeOutput$gene_ID <- gene_ID

return(DEtimeOutput)
}


DEtime_rank <- function(times,ControlData,PerturbedData,replicate_no, gene_no,gene_ID=NULL, savefile=TRUE) {
  
  ## DEtime fits a mixed GP model on two dataset composed of both control data and perturbed data which diverges at a single perturbation point. The two dataset before the presumed perturbation point are fitted with a single GP and after the perturbation point, they are fitted with two independent GPs. The posterior distribution of the tested perturbation points is then obtained from which all thesestatistical info, for example, the MEDIAN, MODE and 5-95 percentile of the distribution can be derived.      
  ## ARG times: The time points of the measured data. At the moment, it is assumed the control and perturbed data are measured at exactly the same time points.
  ## ARG times_test: The time points which will be tested for perturbation effects. The original time points will be used if it is not provided.
  ## ARG replicate_no: The replicate nos of the meaured data. At the moment, same number of replicates are accepted for this model. If this is not provided, the value will be obtained by comparing the size of the measured data and the length of the time points
  ## ARG ControlData : The control dataset used in the model, which is ordered by the first replicate for all time points then the second replicate for all time points and so on
  ## ARG PerturbedData : The perturbed dataset used in the model, which is ordered by the first replicate for all time points then the second replicate for all time points and so on
  ## COPYRIGHT: Jing Yang, 2015
  ##
  
  
  #pathnames <- list.files(pattern="[.]R$", path = "~/*.R", full.names = TRUE)
  #sapply(pathnames,FUN=source)
  
  if (is.null(times)) {
    stop("Time points for the measurements are not provided, pls provide times.")
  }
  
  if (is.null(replicate_no)){
    stop("Replicate no for the measurements is not provided, pls provide replicate_no.")
  }
  
  if (is.null(gene_no)){
    stop("number of genes studies is not provided, pls provide gene_no.")
  }
  
  if (is.null(ControlData)){
    stop("Control data are not provided, pls provide ControlData.")
  }
  else{
    dim(ControlData) <- c(gene_no, length(times)*replicate_no)
  }
  
  if (is.null(PerturbedData)){
    stop("Perturbed data are not provided, pls provide PerturbedData.")
  }
  else{
    dim(PerturbedData) <- c(gene_no, length(times)*replicate_no)
  }
  
  if ((is.null(dim(ControlData)))||(is.null(dim(ControlData)))||(!all.equal((dim(ControlData)),dim(PerturbedData)))){
    stop("Dimension of the input data is not correct, please note ControlData and PerturbedData are both matrix and have to be in the same size.")
  }
  
  
  if (is.null(gene_ID)){
    gene_ID <- as.character(seq(1,gene_no))
  }
  
  if (dim(ControlData)[2] != replicate_no*length(times) || (dim(ControlData)[1] != gene_no)){
    browser()
    stop("Dimension of the data doesn't match, pls double check ")
  }
  
  
  ### interpolation points
  Data <- cbind(PerturbedData, ControlData)
  times_rep2 <- rep(times, 2*replicate_no)
  len_times <- length(times) 
  rank <- matrix(0,nrow=gene_no,ncol=1)
  
  #### model and parameters initialization
  for (idx in seq(1,gene_no)){
    model <- list() ## Allocate space for model.
    ### Initialize hyperparameters used in the GP model
    param <- rep(0, 5)  ## Hyperparameters
    ### Likelihood for each tested perturbation point of each gene
    loglikelihood_minusinfty <- numeric(0) ##  the likelihood
    loglikelihood_infty <- numeric(0) ##  the likelihood
    x <- matrix(times_rep2, ncol=1)
    y <- matrix(scale((Data[idx,]),center=TRUE,scale=TRUE), ncol=1)
    
    options=gpOptions(approx="ftc")
    options$kern = list(type="cmpnd",comp=list(list(type="DEtime",options=list(inverseWidthBounds=c(1/(2*max(times)),1/(min(times)+0.25*(max(times)-min(times)))),varianceBounds=c(min(min(y),0.5),max(max(y),5)))),list(type="white")))
    if (sum(is.nan(y)) > (length(y)/2)) {
      cat('Majority of points in profile are NaN.\n')
      next
    }
    
    options$isMissingData <- any(is.nan(y))
    options$isSpherical <- !any(is.nan(y))
    stdy = sd(c(y[!is.nan(y)])) ## Profile variance.
    
    ## Optimise GP log likelihoods.
    model0 <- gpCreate(dim(x)[2], dim(y)[2], x, y, options)
    model0 <- gpOptimise(model0,0)
    param0 <- gpExtractParam(model0)  ## get optimized hyperparameters
    param0[3] <- -1000.00
    model0 <- gpExpandParam(model0,param0)
    model0 <- gpOptimise(model0,0)
    loglikelihood_minusinfty <- gpLogLikelihood(model0)
    
    param0[3] <- 1000.00
    model1 <- gpExpandParam(model0,param0)
    model1 <- gpOptimise(model1,0)
    loglikelihood_plusinfty <- gpLogLikelihood(model1)
    
    rank[idx] <- loglikelihood_minusinfty - loglikelihood_plusinfty
  }
  res <- data.frame(gene_ID=gene_ID,Loglikelihood_ratio=rank)
  #colnames(res) <- c('gene_ID', 'Loglikelihood_ratio')
  if (savefile){
    write.table(res, "DEtime_result.txt", sep="\t", row.names = FALSE, col.names = TRUE)
    cat('rank list saved in DEtime_rank.txt\n')
  }
  else{ print(res)}
  
  return(res)
  
}
