library(testthat)
library(DEtime)

test_check("DEtime")
